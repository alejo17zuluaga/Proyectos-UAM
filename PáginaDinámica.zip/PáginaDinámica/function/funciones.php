<?php
if (isset($_POST['submit'])){
    $user = $_POST["user"];
    $pass = $_POST["pass"];
    $userDB = "pedro@gmail.com";
    $passDB = "123";

    if ($user === $userDB && $pass === $passDB) {
        header("Location: ../home.html");
        exit();
    } else {
        echo '<script language="javascript">alert("ERROR al ingresar los datos");</script>';
    }
}
?> 