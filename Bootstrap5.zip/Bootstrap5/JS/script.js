console.log("Hola mundo");
var a=43;
var b=32;
var R=a+b;
console.log("Resultado :" + R)

var a=3
var b=12
var R=a*b;
console.log("Resultado :" + R)

var raiz=Math.sqrt(1800)
console.log("Resultado :" + raiz)
var raiz2=Math.trunc(raiz)
console.log("Resultado :" + raiz2)


var c = 500000;
var j = 2;
var numerosPrimos = [];

for (; j < c; j++) {

    if (primo(j)) {
    numerosPrimos.push(j);    
    } 

}

console.log(numerosPrimos);

function primo(numero) {

for (var i=2; i < numero; i++){

    if (numero % i === 0){
        return false;
    }
}
    return numero !== 1;
}

